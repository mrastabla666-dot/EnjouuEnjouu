# Enjouu (Fabric 1.21.1) - by Mr.Teyvat
Build: `gradle build` (JDK 21) -> build/libs/enjouu-1.0.0.jar. Needs Fabric Loader 0.16+ and Fabric API.
Edit NPC dialogue in src/main/java/com/mrteyvat/enjouu/Chat.java.
