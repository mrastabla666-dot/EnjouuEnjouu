package com.mrteyvat.enjouu.client;

import com.mrteyvat.enjouu.Enjouu;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

/** Renders the NPCs as humanoids using a custom 64x64 skin. */
public class EnjouuHumanRenderer<T extends MobEntity> extends BipedEntityRenderer<T, BipedEntityModel<T>> {
    private final Identifier texture;

    public EnjouuHumanRenderer(EntityRendererFactory.Context ctx, String name) {
        super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER)), 0.5f);
        this.texture = Enjouu.id("textures/entity/" + name + ".png");
        addFeature(new HeldItemFeatureRenderer<>(this, ctx.getHeldItemRenderer()));
    }

    @Override
    public Identifier getTexture(T entity) {
        return texture;
    }
}
