package com.mrteyvat.enjouu.entity;

import com.mrteyvat.enjouu.Chat;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Sahil walks to nearby cows, feeds adults (so they breed) and helps calves grow up. */
public class CowCareGoal extends Goal {
    private final SahilEntity mob;
    private CowEntity cow;
    private int cooldown;
    private int repath;

    public CowCareGoal(SahilEntity mob) {
        this.mob = mob;
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (mob.calm > 0) return false;
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        List<CowEntity> cows = mob.getWorld().getEntitiesByClass(CowEntity.class,
                mob.getBoundingBox().expand(16, 4, 16),
                c -> c.isAlive() && (c.isBaby() || (c.getBreedingAge() == 0 && !c.isInLove())));
        if (cows.isEmpty()) {
            cooldown = 40;
            return false;
        }
        cows.sort(Comparator.comparingDouble(c -> c.squaredDistanceTo(mob)));
        cow = cows.get(0);
        return true;
    }

    @Override
    public boolean shouldContinue() {
        return cow != null && cow.isAlive() && mob.calm <= 0 && mob.getTarget() == null
                && mob.squaredDistanceTo(cow) < 400;
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        cow = null;
        cooldown = 60;
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (cow == null) return;
        mob.getLookControl().lookAt(cow, 30.0f, 30.0f);
        if (mob.squaredDistanceTo(cow) > 5.0) {
            if (--repath <= 0) {
                repath = 10;
                mob.getNavigation().startMovingTo(cow, 1.1);
            }
            return;
        }
        mob.swingHand(Hand.MAIN_HAND);
        if (cow.isBaby()) {
            cow.growUp((int) ((-cow.getBreedingAge() / 20) * 0.1f));
        } else {
            cow.lovePlayer(null);
        }
        ((ServerWorld) mob.getWorld()).spawnParticles(ParticleTypes.HEART, cow.getX(), cow.getEyeY() + 0.3, cow.getZ(),
                5, 0.3, 0.3, 0.3, 0.0);
        if (mob.getRandom().nextInt(3) == 0) {
            Chat.say(mob, "Sahil", net.minecraft.util.Formatting.AQUA, Chat.pick(Chat.SAHIL_COW, mob.getRandom()), 12);
        }
        cow = null;
        cooldown = 80;
    }
}
