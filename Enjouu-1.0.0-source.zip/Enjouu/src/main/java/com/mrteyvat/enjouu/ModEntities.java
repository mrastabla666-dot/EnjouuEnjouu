package com.mrteyvat.enjouu;

import com.mrteyvat.enjouu.entity.AnmolEntity;
import com.mrteyvat.enjouu.entity.EnjouuBase;
import com.mrteyvat.enjouu.entity.RaihanEntity;
import com.mrteyvat.enjouu.entity.SahilEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public class ModEntities {
    private static <T extends Entity> EntityType<T> reg(String name, EntityType.Builder<T> builder) {
        return Registry.register(Registries.ENTITY_TYPE, Enjouu.id(name), builder.build(name));
    }

    public static final EntityType<RaihanEntity> RAIHAN = reg("raihan",
            EntityType.Builder.create(RaihanEntity::new, SpawnGroup.CREATURE).dimensions(0.6f, 1.95f).maxTrackingRange(10));
    public static final EntityType<SahilEntity> SAHIL = reg("sahil",
            EntityType.Builder.create(SahilEntity::new, SpawnGroup.CREATURE).dimensions(0.6f, 1.95f).maxTrackingRange(10));
    public static final EntityType<AnmolEntity> ANMOL = reg("anmol",
            EntityType.Builder.create(AnmolEntity::new, SpawnGroup.CREATURE).dimensions(0.6f, 1.95f).maxTrackingRange(10));

    public static void init() {
        FabricDefaultAttributeRegistry.register(RAIHAN, EnjouuBase.baseAttributes());
        FabricDefaultAttributeRegistry.register(SAHIL, EnjouuBase.baseAttributes());
        FabricDefaultAttributeRegistry.register(ANMOL, AnmolEntity.createAttributes());

        SpawnRestriction.register(RAIHAN, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn);
        SpawnRestriction.register(SAHIL, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn);
        SpawnRestriction.register(ANMOL, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn);

        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, RAIHAN, 3, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, SAHIL, 3, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, ANMOL, 2, 1, 1);
    }
}
