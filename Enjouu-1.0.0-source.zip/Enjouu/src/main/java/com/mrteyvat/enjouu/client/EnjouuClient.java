package com.mrteyvat.enjouu.client;

import com.mrteyvat.enjouu.ModBlocks;
import com.mrteyvat.enjouu.ModEntities;
import com.mrteyvat.enjouu.entity.AnmolEntity;
import com.mrteyvat.enjouu.entity.RaihanEntity;
import com.mrteyvat.enjouu.entity.SahilEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.block.Block;
import net.minecraft.client.render.RenderLayer;

public class EnjouuClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(), ModBlocks.CUTOUT.toArray(new Block[0]));
        EntityRendererRegistry.register(ModEntities.RAIHAN, ctx -> new EnjouuHumanRenderer<RaihanEntity>(ctx, "raihan"));
        EntityRendererRegistry.register(ModEntities.SAHIL, ctx -> new EnjouuHumanRenderer<SahilEntity>(ctx, "sahil"));
        EntityRendererRegistry.register(ModEntities.ANMOL, ctx -> new EnjouuHumanRenderer<AnmolEntity>(ctx, "anmol"));
    }
}
