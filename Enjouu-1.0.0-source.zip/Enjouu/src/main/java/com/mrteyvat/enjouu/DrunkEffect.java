package com.mrteyvat.enjouu;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.util.math.random.Random;

/** Drunk: you stumble around randomly and move a bit slower. */
public class DrunkEffect extends StatusEffect {
    public DrunkEffect() {
        super(StatusEffectCategory.HARMFUL, 0x9B3B5A);
        addAttributeModifier(EntityAttributes.GENERIC_MOVEMENT_SPEED, Enjouu.id("drunk_slow"), -0.15,
                EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
    }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        return duration % 15 == 0;
    }

    @Override
    public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
        if (!entity.getWorld().isClient) {
            Random r = entity.getRandom();
            entity.addVelocity((r.nextDouble() - 0.5) * 0.35, 0.0, (r.nextDouble() - 0.5) * 0.35);
            entity.velocityModified = true;
        }
        return true;
    }
}
