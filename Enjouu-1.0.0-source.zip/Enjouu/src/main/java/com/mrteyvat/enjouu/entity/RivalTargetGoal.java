package com.mrteyvat.enjouu.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;

/** Targets the rival NPC as soon as it is seen (unless in a time-out). */
public class RivalTargetGoal<T extends LivingEntity> extends ActiveTargetGoal<T> {
    private final EnjouuBase self;

    public RivalTargetGoal(EnjouuBase mob, Class<T> rival) {
        super(mob, rival, true);
        this.self = mob;
    }

    @Override
    public boolean canStart() {
        return self.calm <= 0 && super.canStart();
    }

    @Override
    public boolean shouldContinue() {
        return self.calm <= 0 && super.shouldContinue();
    }
}
