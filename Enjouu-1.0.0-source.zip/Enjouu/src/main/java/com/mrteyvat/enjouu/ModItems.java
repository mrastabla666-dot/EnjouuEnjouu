package com.mrteyvat.enjouu;

import com.mrteyvat.enjouu.item.BottleDrinkItem;
import com.mrteyvat.enjouu.item.CatArmorItem;
import com.mrteyvat.enjouu.item.CigaretteItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.AliasedBlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ModItems {
    public static final List<Item> ALL = new ArrayList<>();

    private static <T extends Item> T reg(String name, T item) {
        ALL.add(item);
        return Registry.register(Registries.ITEM, Enjouu.id(name), item);
    }

    public static final Item GRAPES = reg("grapes", new AliasedBlockItem(ModBlocks.GRAPE_VINE,
            new Item.Settings().food(new FoodComponent.Builder().nutrition(3).saturationModifier(0.3f).build())));
    public static final Item TOBACCO_SEEDS = reg("tobacco_seeds", new AliasedBlockItem(ModBlocks.TOBACCO_CROP, new Item.Settings()));
    public static final Item TOBACCO_LEAF = reg("tobacco_leaf", new Item(new Item.Settings()));
    public static final Item DRIED_TOBACCO_LEAF = reg("dried_tobacco_leaf", new Item(new Item.Settings()));

    public static final Item DESHI_WINE = reg("deshi_wine", new BottleDrinkItem(new Item.Settings().maxCount(16).food(
            new FoodComponent.Builder().nutrition(1).saturationModifier(0f).alwaysEdible()
                    .statusEffect(new StatusEffectInstance(ModEffects.DRUNK, 2400, 0), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 400, 0), 1.0f)
                    .build())));
    public static final Item CIGARETTE = reg("cigarette", new CigaretteItem(new Item.Settings().maxCount(16).food(
            new FoodComponent.Builder().nutrition(0).saturationModifier(0f).alwaysEdible()
                    .statusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 120, 0), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 200, 0), 1.0f)
                    .build())));

    public static final Item MEOW_PLATING = reg("meow_plating", new Item(new Item.Settings()));
    public static final Item CAT_ARMOR = reg("cat_armor", new CatArmorItem(new Item.Settings().maxCount(1)));

    public static final Item RAIHAN_SPAWN_EGG = reg("raihan_spawn_egg", new SpawnEggItem(ModEntities.RAIHAN, 0x3C7846, 0xE0A040, new Item.Settings()));
    public static final Item SAHIL_SPAWN_EGG = reg("sahil_spawn_egg", new SpawnEggItem(ModEntities.SAHIL, 0xEEEEEE, 0x3070C0, new Item.Settings()));
    public static final Item ANMOL_SPAWN_EGG = reg("anmol_spawn_egg", new SpawnEggItem(ModEntities.ANMOL, 0x8246A0, 0xF0D0F0, new Item.Settings()));

    public static void init() {
        Registry.register(Registries.ITEM_GROUP, Enjouu.id("main"), FabricItemGroup.builder()
                .displayName(Text.translatable("itemGroup.enjouu.main"))
                .icon(() -> new ItemStack(DESHI_WINE))
                .entries((ctx, entries) -> ALL.forEach(entries::add))
                .build());
    }
}
