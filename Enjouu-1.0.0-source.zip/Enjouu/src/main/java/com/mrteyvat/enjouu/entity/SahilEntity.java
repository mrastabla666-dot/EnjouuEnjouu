package com.mrteyvat.enjouu.entity;

import com.mrteyvat.enjouu.Chat;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/** Sahil: cow lover. Feeds and breeds cows, pranks baby villagers, hates Raihan. */
public class SahilEntity extends EnjouuBase {
    public SahilEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world, "Sahil", Formatting.AQUA);
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.WHEAT));
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.add(3, new CowCareGoal(this));
        goalSelector.add(4, new ScareBabyVillagerGoal(this));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.7));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RivalTargetGoal<RaihanEntity>(this, RaihanEntity.class));
    }

    @Override
    protected String[] fightLines() {
        return Chat.SAHIL_FIGHT;
    }

    @Override
    protected void serverTick() {
        super.serverTick();
        if (calm <= 0 && getTarget() == null && chatCooldown == 0 && age % 20 == 0) {
            ServerWorld sw = (ServerWorld) getWorld();
            if (!sw.getPlayers(p -> p.squaredDistanceTo(this) < 36).isEmpty()) {
                Chat.say(this, npcName, color, Chat.pick(Chat.SAHIL_COW, random), 6);
                chatCooldown = 200 + random.nextInt(200);
            }
        }
    }
}
