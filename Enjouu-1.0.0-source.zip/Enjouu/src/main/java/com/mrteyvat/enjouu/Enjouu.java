package com.mrteyvat.enjouu;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradedItem;
import net.minecraft.village.VillagerProfession;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;

public class Enjouu implements ModInitializer {
    public static final String MOD_ID = "enjouu";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEffects.init();
        ModBlocks.init();
        ModEntities.init();
        ModItems.init();

        TradeOfferHelper.registerVillagerOffers(VillagerProfession.FARMER, 1, f -> {
            f.add((e, r) -> new TradeOffer(new TradedItem(Items.EMERALD, 1), new ItemStack(ModItems.TOBACCO_SEEDS, 4), 16, 2, 0.05f));
            f.add((e, r) -> new TradeOffer(new TradedItem(ModItems.GRAPES, 20), new ItemStack(Items.EMERALD, 1), 16, 2, 0.05f));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.FARMER, 2, f ->
                f.add((e, r) -> new TradeOffer(new TradedItem(Items.EMERALD, 3), new ItemStack(ModItems.DESHI_WINE, 1), 8, 5, 0.05f)));

        BiomeModifications.addFeature(
                BiomeSelectors.includeByKey(BiomeKeys.JUNGLE, BiomeKeys.SPARSE_JUNGLE, BiomeKeys.BAMBOO_JUNGLE),
                GenerationStep.Feature.VEGETAL_DECORATION,
                RegistryKey.of(RegistryKeys.PLACED_FEATURE, id("wild_grapes")));
        BiomeModifications.addFeature(
                BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.SAVANNA, BiomeKeys.SUNFLOWER_PLAINS),
                GenerationStep.Feature.VEGETAL_DECORATION,
                RegistryKey.of(RegistryKeys.PLACED_FEATURE, id("wild_tobacco")));
    }
}
