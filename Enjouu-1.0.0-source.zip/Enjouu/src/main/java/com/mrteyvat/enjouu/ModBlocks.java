package com.mrteyvat.enjouu;

import com.mrteyvat.enjouu.block.EnjouuCropBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class ModBlocks {
    public static final List<Block> CUTOUT = new ArrayList<>();

    private static Block crop(String name, Supplier<Item> seeds) {
        Block b = Registry.register(Registries.BLOCK, Enjouu.id(name),
                new EnjouuCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT), seeds));
        CUTOUT.add(b);
        return b;
    }

    public static final Block GRAPE_VINE = crop("grape_vine", () -> ModItems.GRAPES);
    public static final Block TOBACCO_CROP = crop("tobacco_crop", () -> ModItems.TOBACCO_SEEDS);

    public static void init() {
    }
}
